/* Default linker script, for normal executables */
/* Copyright (C) 2014-2017 Free Software Foundation, Inc.
   Copying and distribution of this script, with or without modification,
   are permitted in any medium without royalty provided the copyright
   notice and this notice are preserved.  */
OUTPUT_FORMAT(a.out-mintprg)
SEARCH_DIR("=/usr/m68k-atari-mint/lib"); SEARCH_DIR("=/usr/local/lib"); SEARCH_DIR("=/lib"); SEARCH_DIR("=/usr/lib");
SECTIONS
{
  /* The VMA of the .text section is 0xe4 instead of 0
     because the extended MiNT header is just before,
     at the beginning of the TEXT segment.  */
  .text 0xe4:
  {
    CREATE_OBJECT_SYMBOLS
    *(.text)
    CONSTRUCTORS
    etext = .;
    _etext = .;
    __etext = .;
  }
  .data :
  {
    *(.data)
    _edata = .;
    __edata = .;
  }
  .bss :
  {
    __bss_start = .;
    *(.bss)
    *(COMMON)
    _end = .;
    __end = .;
  }
  /* Discard the following ELF sections.
   * Some of them may be present in ELF libgcc.a.
   */
  /DISCARD/ :
  {
      *(.comment)
      *(.debug*)
      *(.note*)
      *(.gnu.attributes)
  }
}
